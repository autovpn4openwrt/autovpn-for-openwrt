#!/bin/sh
IPS=`echo $1|tr "," "\n"`
DEV=`ifconfig |grep -e "pos-"|cut -d" " -f 1|head -n 1`
ROUTES=/tmp/routes.txt

if [ -n "$IPS" ] ;then
    for ip in $IPS ;do
        route -n|grep $ip|grep -q $DEV
        if [ $? -ne 0 ];then
            echo "add $ip to route table"
            route add $ip/32 dev $DEV
            echo "$ip" >>$ROUTES
        fi
    done
fi
